var struct_r_g_b =
[
    [ "b", "struct_r_g_b.html#a41cede1b4c0d05cff170ad5761f70964", null ],
    [ "g", "struct_r_g_b.html#a83576af39a9f289a28c1263d61073508", null ],
    [ "r", "struct_r_g_b.html#afd7b1ea9ff115205b65e0bffc92946ac", null ]
];