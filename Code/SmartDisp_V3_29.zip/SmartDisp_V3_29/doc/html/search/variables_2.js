var searchData=
[
  ['delayms_77',['delayMS',['../_smart_disp___v2__08_8ino.html#a2a9fec03258233e351f904b67c9bb1af',1,'SmartDisp_V2_08.ino']]]
];
