var searchData=
[
  ['writechartomatrix_72',['writeCharToMatrix',['../_smart_disp___v2__08_8ino.html#a017a66a98144c46c13ad67a4e54b6606',1,'SmartDisp_V2_08.ino']]],
  ['writerainbowtomatrix_73',['writeRainbowToMatrix',['../_smart_disp___v2__08_8ino.html#a5d512c67b8a6d11908c89436e74f4d71',1,'SmartDisp_V2_08.ino']]]
];
