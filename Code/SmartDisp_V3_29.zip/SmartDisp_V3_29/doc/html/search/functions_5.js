var searchData=
[
  ['overridecolorpixels_62',['overrideColorPixels',['../_smart_disp___v2__08_8ino.html#a33632c39ba8955f8a1bcb7cbbb540be4',1,'SmartDisp_V2_08.ino']]]
];
