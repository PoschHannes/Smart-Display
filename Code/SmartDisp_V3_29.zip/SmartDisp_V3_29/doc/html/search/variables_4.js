var searchData=
[
  ['g_79',['g',['../struct_r_g_b.html#a83576af39a9f289a28c1263d61073508',1,'RGB']]]
];
