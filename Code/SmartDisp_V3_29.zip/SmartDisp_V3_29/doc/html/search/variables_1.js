var searchData=
[
  ['b_76',['b',['../struct_r_g_b.html#a41cede1b4c0d05cff170ad5761f70964',1,'RGB']]]
];
