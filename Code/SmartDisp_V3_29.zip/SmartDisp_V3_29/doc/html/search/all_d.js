var searchData=
[
  ['r_34',['r',['../struct_r_g_b.html#afd7b1ea9ff115205b65e0bffc92946ac',1,'RGB']]],
  ['rainbow_5fmultiplier_35',['RAINBOW_MULTIPLIER',['../_smart_disp___v2__08_8ino.html#a65dcfa95d6c668484d0308b9e9d5362d',1,'SmartDisp_V2_08.ino']]],
  ['relcaluclation_36',['relCaluclation',['../_smart_disp___v2__08_8ino.html#a57e3c162ac3c2dd02d110de9f9c6fe08',1,'SmartDisp_V2_08.ino']]],
  ['rgb_37',['RGB',['../struct_r_g_b.html',1,'']]],
  ['rowone_38',['rowOne',['../_smart_disp___v2__08_8ino.html#a0c66f0bc1a6eb3a7bc4ca5c88cb4146a',1,'SmartDisp_V2_08.ino']]],
  ['rowzero_39',['rowZero',['../_smart_disp___v2__08_8ino.html#a8c9e58baa28483c77a59f33aed82efd9',1,'SmartDisp_V2_08.ino']]],
  ['rtctomatrix_40',['RTCToMatrix',['../_smart_disp___v2__08_8ino.html#aab96a09f0f3993335c2741328def1d3f',1,'SmartDisp_V2_08.ino']]]
];
