var searchData=
[
  ['pixels_63',['pixels',['../_smart_disp___v2__08_8ino.html#a50f528426ed069c28b8c510f38430b38',1,'SmartDisp_V2_08.ino']]],
  ['printtemperature_64',['printTemperature',['../_smart_disp___v2__08_8ino.html#af6d668d07fdef904d7e453ada9b1e407',1,'SmartDisp_V2_08.ino']]]
];
