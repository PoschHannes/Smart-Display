var searchData=
[
  ['colortext_50',['colorText',['../_smart_disp___v2__08_8ino.html#a6b3bc68c4fdaef6dca16795d7c3f7d2b',1,'SmartDisp_V2_08.ino']]],
  ['colortext1_51',['colorText1',['../_smart_disp___v2__08_8ino.html#aff3854d227697683912b38567220dad0',1,'SmartDisp_V2_08.ino']]],
  ['colortext2_52',['colorText2',['../_smart_disp___v2__08_8ino.html#af026a209a576a2ffbd6583174805ebe8',1,'SmartDisp_V2_08.ino']]],
  ['copyinvrow_53',['copyInvRow',['../_smart_disp___v2__08_8ino.html#a763566f7d158a517b7c0b0669850a648',1,'SmartDisp_V2_08.ino']]],
  ['copyrow_54',['copyRow',['../_smart_disp___v2__08_8ino.html#a4e5cd315458c98f568fdfa03fc0247db',1,'SmartDisp_V2_08.ino']]]
];
