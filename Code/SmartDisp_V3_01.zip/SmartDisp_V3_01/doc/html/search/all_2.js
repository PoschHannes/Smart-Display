var searchData=
[
  ['clock_5ftime_3',['CLOCK_TIME',['../_smart_disp___v2__08_8ino.html#a4adbc70d7a3a6c912e42d1f91fcc94a8',1,'SmartDisp_V2_08.ino']]],
  ['colortext_4',['colorText',['../_smart_disp___v2__08_8ino.html#a6b3bc68c4fdaef6dca16795d7c3f7d2b',1,'SmartDisp_V2_08.ino']]],
  ['colortext1_5',['colorText1',['../_smart_disp___v2__08_8ino.html#aff3854d227697683912b38567220dad0',1,'SmartDisp_V2_08.ino']]],
  ['colortext2_6',['colorText2',['../_smart_disp___v2__08_8ino.html#af026a209a576a2ffbd6583174805ebe8',1,'SmartDisp_V2_08.ino']]],
  ['copyinvrow_7',['copyInvRow',['../_smart_disp___v2__08_8ino.html#a763566f7d158a517b7c0b0669850a648',1,'SmartDisp_V2_08.ino']]],
  ['copyrow_8',['copyRow',['../_smart_disp___v2__08_8ino.html#a4e5cd315458c98f568fdfa03fc0247db',1,'SmartDisp_V2_08.ino']]]
];
