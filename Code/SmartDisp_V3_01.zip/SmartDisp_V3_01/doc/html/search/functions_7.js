var searchData=
[
  ['relcaluclation_65',['relCaluclation',['../_smart_disp___v2__08_8ino.html#a57e3c162ac3c2dd02d110de9f9c6fe08',1,'SmartDisp_V2_08.ino']]],
  ['rowone_66',['rowOne',['../_smart_disp___v2__08_8ino.html#a0c66f0bc1a6eb3a7bc4ca5c88cb4146a',1,'SmartDisp_V2_08.ino']]],
  ['rowzero_67',['rowZero',['../_smart_disp___v2__08_8ino.html#a8c9e58baa28483c77a59f33aed82efd9',1,'SmartDisp_V2_08.ino']]],
  ['rtctomatrix_68',['RTCToMatrix',['../_smart_disp___v2__08_8ino.html#aab96a09f0f3993335c2741328def1d3f',1,'SmartDisp_V2_08.ino']]]
];
