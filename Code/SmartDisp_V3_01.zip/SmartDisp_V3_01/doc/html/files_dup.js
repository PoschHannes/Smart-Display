var files_dup =
[
    [ "italic5x5_font.h", "italic5x5__font_8h.html", "italic5x5__font_8h" ],
    [ "SmartDisp_V2_08.ino", "_smart_disp___v2__08_8ino.html", "_smart_disp___v2__08_8ino" ]
];