var annotated_dup =
[
    [ "RGB", "struct_r_g_b.html", "struct_r_g_b" ]
];