var searchData=
[
  ['numpixels_90',['NUMPIXELS',['../_smart_disp___v2__08_8ino.html#a733f7d5b0fd44b87044a3fc9d4594ceb',1,'SmartDisp_V2_08.ino']]]
];
