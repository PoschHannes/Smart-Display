var searchData=
[
  ['matrix_24',['matrix',['../_smart_disp___v2__08_8ino.html#a8d7662e6c6dd10fe2911b7cec2920c16',1,'SmartDisp_V2_08.ino']]],
  ['matrix_5fdimension_5fx_25',['MATRIX_DIMENSION_X',['../_smart_disp___v2__08_8ino.html#afc27679c56770e2729b32546f577279f',1,'SmartDisp_V2_08.ino']]],
  ['matrix_5fdimension_5fy_26',['MATRIX_DIMENSION_Y',['../_smart_disp___v2__08_8ino.html#abe01cd5120e1ed7d814bfe6ace5a72cf',1,'SmartDisp_V2_08.ino']]],
  ['max_5frainbow_5fcolor_27',['MAX_RAINBOW_COLOR',['../_smart_disp___v2__08_8ino.html#ae625cf80d090cadb440a8b23fa72be82',1,'SmartDisp_V2_08.ino']]],
  ['maxcolor_28',['MAXCOLOR',['../_smart_disp___v2__08_8ino.html#acd61a23b73083918e86cc349ed38c076',1,'SmartDisp_V2_08.ino']]]
];
