var searchData=
[
  ['setup_41',['setup',['../_smart_disp___v2__08_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'SmartDisp_V2_08.ino']]],
  ['shifttext_42',['shiftText',['../_smart_disp___v2__08_8ino.html#aafecc54243e417e61e69863e2e5fa0cd',1,'SmartDisp_V2_08.ino']]],
  ['smartdisp_5fv2_5f08_2eino_43',['SmartDisp_V2_08.ino',['../_smart_disp___v2__08_8ino.html',1,'']]]
];
