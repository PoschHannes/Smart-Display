var indexSectionsWithContent =
{
  0: "_bcdfghilmnoprstw",
  1: "r",
  2: "is",
  3: "cdfhloprstw",
  4: "_bdfgmr",
  5: "cdmnpr",
  6: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Modules"
};

