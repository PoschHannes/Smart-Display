var italic5x5__font_8h =
[
    [ "font", "italic5x5__font_8h.html#a702609e921e8bf92d99710ea8d60fe4c", null ]
];